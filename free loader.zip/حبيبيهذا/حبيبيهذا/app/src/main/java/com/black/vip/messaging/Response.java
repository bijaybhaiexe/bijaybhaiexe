package com.black.vip.messaging;
import io.michaelrocks.paranoid.Obfuscate;

@Obfuscate
public class Response {
    public int success;
}
