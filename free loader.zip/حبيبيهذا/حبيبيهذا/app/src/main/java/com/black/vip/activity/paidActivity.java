package com.black.vip.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.black.vip.Config;
import com.black.vip.R;
import com.black.vip.utils.FLog;
import com.black.vip.utils.UiKit;
import com.black.vip.utils.FPrefs;
import io.michaelrocks.paranoid.Obfuscate;

@Obfuscate
public class paidActivity extends AppCompatActivity {
    LottieAnimationView animationView;
    TextView descTitle;
    
    public FPrefs getPref() {
        return FPrefs.with(this);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler(this));
        setContentView(R.layout.paid);
        animationView = findViewById(R.id.animationView);
        descTitle = findViewById(R.id.descTitle);               
        }
    }
 
    
